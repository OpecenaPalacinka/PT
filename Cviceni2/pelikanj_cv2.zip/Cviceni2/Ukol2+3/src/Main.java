public class Main {

    public static void main(String[] args) {
	Zivocich prvniZiv = new Zivocich();
	Savec prvniSav = new Savec();
	Obratlovec prvniObra = new Obratlovec();
	Savec druhySav = new Savec();
    }

}
