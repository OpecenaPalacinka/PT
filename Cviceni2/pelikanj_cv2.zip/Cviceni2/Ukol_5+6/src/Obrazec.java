public abstract class Obrazec {
    public abstract double spoctiObvod();
}
